const WISHES = [
  ["SHR","happy birthday sania!!!(and also sorry for late verison hahaha~"],
  ["supertomatomato","wish u a big fortune in future~~"],
  ["hairong","may you happy everyday!!!"]
  ["Aladdin", "may your depression go away soon!!"],
  ["Aladdin", "wish your relationship with your parents and siblings getting better!!!"],
  ["Aladdin", "may you and your sibling get great education you want in future!!!!!"],
 
];
